define("epi-cms/contentediting/inline-editing/CreateNewInlineBlockEditFormContainer", [
    "dojo/_base/declare",
    "epi-cms/contentediting/inline-editing/CreateNewBlockEditFormContainer"
], function (
    declare,
    CreateNewBlockEditFormContainer) {
    return declare([CreateNewBlockEditFormContainer], {
        autoStartup: false,

        saveModel: function (contentType, name) {
            this.createContentViewModel.saveLocalBlock({
                name: name || contentType.localizedName,
                contentTypeId: contentType.id,
                inlineBlockData: Object.assign(this.get("value"), { isModified: true }),
                typeIdentifier: contentType.typeIdentifier,
                contentTypeName: contentType.localizedName
            });
        }
    });
});
