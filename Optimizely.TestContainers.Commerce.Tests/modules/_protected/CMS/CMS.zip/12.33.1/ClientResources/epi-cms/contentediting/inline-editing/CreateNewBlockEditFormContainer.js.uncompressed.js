define("epi-cms/contentediting/inline-editing/CreateNewBlockEditFormContainer", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/topic",
    "epi/dependency",
    "epi-cms/contentediting/inline-editing/BlockEditFormContainer",
    "epi-cms/contentediting/viewmodel/CreateContentViewModel"
], function (
    declare,
    Deferred,
    topic,
    dependency,
    BlockEditFormContainer,
    CreateContentViewModel) {
    return declare([BlockEditFormContainer], {
        _contextService: null,

        autoStartup: true,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.createContentViewModel = new CreateContentViewModel({
                createAsLocalAsset: true,
                ignoreDefaultNameWarning: true
            });
        },

        buildRendering: function () {
            this.inherited(arguments);

            this._contextService = this._contextService || dependency.resolve("epi.shell.ContextService");
            this._contextService.currentContext = this._contextService.currentContext || {};

            this._setCreateMode();
        },

        onFieldCreated: function (fieldName, widget) {
            // override parent to avoid null exception
        },

        _setAddToDestinationAttr: function (model) {
            this.createContentViewModel.set("addToDestination", model);
        },

        _setAutoPublishAttr: function (autoPublish) {
            this.createContentViewModel.set("autoPublish", autoPublish);
        },

        reloadMetadata: function (parent, contentTypeId) {
            this.createContentViewModel.set({
                parent: parent,
                contentTypeId: contentTypeId
            });

            return this.createContentViewModel._getMetadata(parent.contentLink, contentTypeId).then(function (metadata) {
                this.set("metadata", metadata);
                this.startup();
            }.bind(this));
        },

        saveForm: function (contentType, name) {
            var deferred = new Deferred();

            var saveHandle = this.createContentViewModel.on("saveSuccess", function (result) {
                this._clearCreateMode();
                saveHandle.remove();
                // eslint-disable-next-line no-use-before-define
                errorHandle.remove();
                deferred.resolve(result);

                topic.publish("/epi/cms/action/createlocalasset");
            }.bind(this));
            var errorHandle = this.createContentViewModel.on("saveError", function () {
                saveHandle.remove();
                errorHandle.remove();
                var errorsMessages = [];
                this.validator._store.query().forEach(function (error) {
                    if (error && error.item && error.item.errorMessage) {
                        errorsMessages.push(error.item.errorMessage);
                    }
                });
                deferred.reject(errorsMessages);
            });

            // Only set name when it's given.
            // In the case the block name property is hidden, the block name will be generated automatically.
            if (this.get("value") && (this.get("value").name || this.get("value").icontent_name)) {
                this.createContentViewModel.set("contentName", this.get("value").name || this.get("value").icontent_name);
            } else {
                this.createContentViewModel.set("autoGenerateName", true);
            }
            this.createContentViewModel.set("properties", this.get("value"));
            this.saveModel(contentType, name);
            return deferred.promise;
        },

        saveModel: function () {
            this.createContentViewModel.save();
        },

        _setCreateMode: function () {
            this._contextService.currentContext.currentMode = "create";
        },

        _clearCreateMode: function () {
            this._contextService.currentContext.currentMode = undefined;
        },

        _onFormCreated: function () {
            this.inherited(arguments);
            var value = this.get("value");
            var isDirty = Object.keys(value).length > 0;
            this.set("isDirty", isDirty);
            this.emit("isDirty", isDirty);
        }
    });
});
