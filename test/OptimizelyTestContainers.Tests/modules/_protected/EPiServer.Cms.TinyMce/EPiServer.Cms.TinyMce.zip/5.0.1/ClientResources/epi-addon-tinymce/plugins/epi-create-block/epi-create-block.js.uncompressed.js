define("epi-addon-tinymce/plugins/epi-create-block/epi-create-block", [
    "dojo/aspect",
    "epi-cms/ApplicationSettings",
    "epi-addon-tinymce/tinymce-loader",
    "epi-cms/widget/command/CreateContentFromSelector",
    "epi-addon-tinymce/ContentService",
    "epi-addon-tinymce/plugins/epi-dnd-processor/dndDropProcessor",
    "epi-cms/widget/command/DefaultContentSelectorPlugAndPlayCommand",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epicreateblock",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentselectorplugandplay"
], function (
    aspect,
    ApplicationSettings,
    tinymce,
    CreateContentFromSelector,
    ContentService,
    DndDropProcessor,
    DefaultContentSelectorPlugAndPlayCommand,
    pluginResource,
    selectorResource
) {

    tinymce.PluginManager.add("epi-create-block", function (editor) {
        // When blocks management is not enabled, then do not show toolbar button
        if (editor.getParam("allowBlocksInsideTinyMce") === false) {
            return;
        }

        // We do not allow to create local blocks in Create mode because
        // we don't have the contextual folder (For this page/block) yet
        // that could be the parent for newly created local block
        if (editor.isInCreateMode || !editor.hasCreateAccessRights) {
            return;
        }

        // We do not allow to create local blocks inside inline blocks (as part of ContentAreaItem)
        // but we do allow it when editing a shared block via Quick Edit
        if (editor.isInQuickEditMode && !editor._contentLink) {
            return;
        }

        var self = this;

        function mceEPiCreateBlock(buttonApi) {
            if (!buttonApi.isEnabled()) {
                return;
            }

            var command = new CreateContentFromSelector({
                creatingTypeIdentifier: "episerver.core.blockdata",
                createAsLocalAsset: true,
                isInQuickEditMode: editor.isInQuickEditMode,
                quickEditBlockId: editor._contentLink,
                keepCurrentView: editor.isEditing || self.isFullScreen,
                suppressOverlayAdjustments: self.isFullScreen,
                autoPublish: true
            });

            var contentService = new ContentService();

            command.set("model", {
                save: function (block) {
                    contentService.getContent(block.contentLink).then(function (model) {
                        var item = {
                            type: ["episerver.core.blockdata"],
                            data: model
                        };
                        var processor = new DndDropProcessor(editor);
                        processor.processData(item);
                    });
                }.bind(this),
                cancel: function () { }
            });
            command.execute();
        }

        function selectContent(buttonApi) {
            if (!buttonApi.isEnabled()) {
                return;
            }

            var contentSelectorDialogSettings = {
                roots: [ApplicationSettings.rootPage],
                allowedTypes: ["episerver.core.icontent", "episerver.core.icontentdata"],
                canSelectOwnerContent: false,
                getCurrentValue: function () {
                    return undefined;
                },
                isInQuickEditMode: editor.isInQuickEditMode,
                quickEditBlockId: editor._contentLink
            };

            var dialogSettings = Object.assign({
                title: selectorResource.dialogtitle,
                dialogClass: "epi-dialog-portrait epi-content-selector-plugnplay-dialog",
                destroyOnHide: true
            }, this.dialogSettings || {});

            var command = new DefaultContentSelectorPlugAndPlayCommand({
                contentSelectorDialogSettings: contentSelectorDialogSettings,
                dialogSettings: dialogSettings,
                canExecute: true
            });
            command.execute();
            var executeHandle = aspect.after(command, "onDialogExecute", function (sender, args) {
                var contentLink = args[0];

                var contentService = new ContentService();
                contentService.getContent(contentLink).then(function (model) {
                    var item = {
                        type: [],
                        data: model
                    };
                    var processor = new DndDropProcessor(editor);
                    processor.processData(item);
                });
            });

            var hideHandle = aspect.after(command.dialog, "onHide", function () {
                executeHandle.remove();
                hideHandle.remove();
            });
        }

        editor.on("FullscreenStateChanged", function (event) {
            self.isFullScreen = event.state;
        });

        editor.ui.registry.addIcon("epi-iconCreateSharedBlock", "<div class='epi-iconCreateSharedBlock'></div>");

        // Register buttons
        editor.ui.registry.addSplitButton("epi-create-block", {
            tooltip: pluginResource.title,
            onAction: mceEPiCreateBlock,
            icon: "epi-iconCreateSharedBlock",
            type: "splitbutton",
            fetch: function (callback) {
                var items = [];

                var createContentItem = {
                    type: "choiceitem",
                    value: "create",
                    text: pluginResource.create
                };
                items.push(createContentItem);

                var selectContentItem = {
                    type: "choiceitem",
                    value: "select",
                    text: pluginResource.select
                };
                items.push(selectContentItem);

                callback(items);
            },
            onItemAction: function (splitButtonApi, value) {
                if (value === "create") {
                    mceEPiCreateBlock(splitButtonApi);
                    return;
                }

                selectContent(splitButtonApi);
            },
            onSetup: function (buttonApi) {
                function selectionChange() {
                    var isTextSelected = editor.selection.getContent() !== "";
                    buttonApi.setEnabled(!(editor.readonly || isTextSelected));
                }

                editor.on("SelectionChange", selectionChange);

                return function () {
                    editor.off("SelectionChange", selectionChange);
                };
            }
        });

        editor.shortcuts.add("ctrl+l", pluginResource.title, mceEPiCreateBlock);

        return {
            getMetadata: function () {
                return {
                    name: "Create block (optimizely)",
                    url: "https://www.optimizely.com/"
                };
            }
        };
    });
});
