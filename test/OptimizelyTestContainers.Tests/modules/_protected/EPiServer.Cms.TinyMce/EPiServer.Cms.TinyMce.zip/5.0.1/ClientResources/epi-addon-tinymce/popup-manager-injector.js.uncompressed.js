﻿define("epi-addon-tinymce/popup-manager-injector", [
    "dojo/_base/declare",
    "dojo/aspect",
    "dijit/Destroyable",
    "dijit/popup"
],
function (
    declare,
    aspect,
    Destroyable,
    popup
) {
    return declare([Destroyable], {
        // summary:
        //      A base class implementation for commands.
        // tags:
        //      public abstract

        postscript: function (editor)  {
            this.inherited(arguments);

            this.own(aspect.after(popup, "open", function (result, inputArgs) {
                if (editor.isShowingChildDialog) {
                    var wrapper = inputArgs[0];
                    if (wrapper && wrapper.popup && wrapper.popup._popupWrapper) {
                        wrapper.popup._popupWrapper.style.zIndex = "10000";
                    }
                }
            }.bind(this)));
        }
    });
});
