﻿define("epi-addon-tinymce/get-language-mapping", [], function () {
    return function getLanguageMapping(epiLanguage) {
        if (!epiLanguage) {
            return undefined;
        }

        epiLanguage = (epiLanguage || "").toLowerCase();

        // all English cultures should be resolved as undefined
        // and
        if (epiLanguage.indexOf("en-") === 0) {
            return undefined;
        }

        switch (epiLanguage) {
            case "da-dk":
                return "da";
            case "de-de":
                return "de";
            case "fi-fi":
                return "fi";
            case "es-es":
                return "es";
            case "fr-fr":
                return "fr_FR";
            case "it-it":
                return "it";
            case "ja-jp":
                return "ja";
            case "nb-no":
                return "nb_NO";
            case "nl-nl":
                return "nl";
            case "sv-se":
                return "sv_SE";
            case "zh-cn":
                return "zh-Hans";
            default:
                return epiLanguage;
        }
    };
});
